<template>
    <div class="home-container page-container container">
        <div class="title">
            Ali Babayev
        </div>
        <p>
            I'm Babayev Ali was born in Lenkoran in 10.08.2002. And I am a web developer with more than 1 year of
            experience. I studied by myself without any courses or schools. I have experience working with a team. A
            responsible and hardworking person. I enjoy writing code and therefore work without rest and this is a bad
            trait of my character.
        </p>
        <hr>
        <div class="title">
            <i class="fas fa-award mr-1 "></i> Skills
        </div>
        <div class="skills row w-100">
            <div class="item w-100 mb-2">
                <div class="col-12">
                    PHP
                </div>
                <div class="col-12">
                    <div class="progress w-100">
                        <div class="progress-bar bg-dark" role="progressbar" style="width: 85%;" aria-valuenow="85"
                            aria-valuemin="0" aria-valuemax="100">85%</div>
                    </div>
                </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    Laravel
                </div>
                <div class="col-12">
                    <div class="progress w-100">
                        <div class="progress-bar bg-dark" role="progressbar" style="width: 80%;" aria-valuenow="80"
                            aria-valuemin="0" aria-valuemax="100">80%</div>
                    </div>
                </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    Node JS
                </div>
                <div class="col-12">
                    <div class="progress w-100">
                        <div class="progress-bar bg-dark" role="progressbar" style="width: 75%;" aria-valuenow="75"
                            aria-valuemin="0" aria-valuemax="100">75%</div>
                    </div>
                </div>
            </div>
            <div class="item w-100">
                <div class="col-12">
                    ExpressJS
                </div>
                <div class="col-12">
                    <div class="progress w-100">
                        <div class="progress-bar bg-dark" role="progressbar" style="width: 75%;" aria-valuenow="75"
                            aria-valuemin="0" aria-valuemax="100">75%</div>
                    </div>
                </div>
            </div>
            <router-link tag="a" to="/skills" class="more-btn text-muted">
                        more skills
                    </router-link>
        </div>
        <hr>
        <div class="title mt-2">
            <i class="fas fa-shield-virus mr-1 "></i> Participated in the development of the following projects
        </div>
        <div class="projects row w-100">
            <div class="project-item col-12">
                <div class="title">
                    nizami880.az
                </div>
                <div class="content">
                    I have order make eCommerce website for EPONA. But after some time EPONA has canceled this order.
                    I have used NodeJS, ExpressJS, MongoDB technologies
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    kapitalbank.az
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This
                    project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    seabreeze.az
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This
                    project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    ligthouse.az
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This
                    project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    hr.oba.az
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This
                    project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    caspianentertainment.com
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This
                    project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <router-link tag="a" to="/projects" class="more-btn text-muted">
                        more projects
                    </router-link>
        </div>
        <hr>
        <div class="title">
            <i class="fas fa-shield-virus mr-1 "></i> Projects
        </div>
        <div class="projects row w-100">
           <div class="project-item col-12">
                <div class="title">
                    Epona (e-commerce)
                </div>
                <div class="content">
                    I have order make eCommerce website for EPONA. But after some time EPONA has canceled this order.
                    I have used NodeJS, ExpressJS, MongoDB technologies
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    HAZIRCAVAB
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                   My Portfolio website
                </div>
                <div class="content">
                    This is my Portfolio website. There is all information about me, my skills and e.t.c.
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                   E-school
                </div>
                <div class="content">
                    This is my Portfolio website. There is all information about me, my skills and e.t.c.
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                
                <div class="title">
                   Email sender application
                </div>
                <div class="content">
                    An application written using laravel and php
                </div>
            </div>
            <router-link tag="a" to="/projects" class="more-btn text-muted">
                        more projects
                    </router-link>
        </div>
    

    </div>
</template>
