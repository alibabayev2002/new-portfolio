<template>
   <div class="page-container container">
    
        <div class="title">
            <i class="fas fa-shield-virus mr-1 "></i> Projects
        </div>
        <div class="projects row w-100">
            <div class="project-item col-12">
                <div class="title">
                    Epona (e-commerce)
                </div>
                <div class="content">
                    I have order make eCommerce website for EPONA. But after some time EPONA has canceled this order.
                    I have used NodeJS, ExpressJS, MongoDB technologies
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                   Individual Project - HAZIRCAVAB
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                   My Portfolio website
                </div>
                <div class="content">
                    This is my Portfolio website. There is all information about me, my skills and e.t.c.
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                   E-school
                </div>
                <div class="content">
                    This is my Portfolio website. There is all information about me, my skills and e.t.c.
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                
                <div class="title">
                   Email sender application
                </div>
                <div class="content">
                    An application written using laravel and php
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    Collision game
                </div>
                <div class="content">
                    App i write when i'm bored
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    Blog (tech)
                </div>
                <div class="content">
                    App i write when i'm bored
                </div>
            </div>
        </div>
         <hr>
         <div class="title mt-2">
            Participated in the development of the following projects
        </div>
        <div class="projects row w-100">
            <div class="project-item col-12">
                <div class="title">
                    nizami880.az
                </div>
                <div class="content">
                    I have order make eCommerce website for EPONA. But after some time EPONA has canceled this order.
                    I have used NodeJS, ExpressJS, MongoDB technologies
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                   kapitalbank.az
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    seabreeze.az
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    ligthouse.az
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    hr.oba.az
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
            <div class="project-item col-12">
                <div class="title">
                    caspianentertainment.com
                </div>
                <div class="content">
                    We started individual project with my friend. He developed back-end and I developed Front-end. This project we have in Github. We have closed project becease of Education.
                </div>
            </div>
        </div>

   </div>
</template>
