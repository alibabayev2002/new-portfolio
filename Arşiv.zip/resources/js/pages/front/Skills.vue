<template>
    <div class="page-container container">
        <div class="title">
           <i class="fas fa-award mr-1 "></i> Skills
        </div>
        <div class="skills row w-100">
            <div class="item w-100 mb-2">
                <div class="col-12">
                    HTML
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 95%;"
                                aria-valuenow="95" aria-valuemin="0" aria-valuemax="100">95%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    CSS
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 95%;"
                                aria-valuenow="95" aria-valuemin="0" aria-valuemax="100">95%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    Bootstrap
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 95%;"
                                aria-valuenow="95" aria-valuemin="0" aria-valuemax="100">95%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    SASS , LESS
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 75%;"
                                aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    Javascript
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 80%;"
                                aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">80%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    Jquery , AJAX
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 90%;"
                                aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">90%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    VueJS
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 70%;"
                                aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">70%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    SPA
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 80%;"
                                aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">80%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    Node JS
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 75%;"
                                aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100">
                <div class="col-12">
                    ExpressJS
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 75%;"
                                aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    PHP
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 85%;"
                                aria-valuenow="85" aria-valuemin="0" aria-valuemax="100">85%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    Laravel
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 80%;"
                                aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">80%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    OOP , MVC
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 70%;"
                                aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">70%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                    Rest API
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 90%;"
                                aria-valuenow="90" aria-valuemin="0" aria-valuemax="100">90%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                   Firebase
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 80%;"
                                aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">80%</div>
                        </div>
                    </div>
            </div>
             <div class="item w-100 mb-2">
                <div class="col-12">
                   MySQL
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 80%;"
                                aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">80%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                   PostgreSQL
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 80%;"
                                aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">80%</div>
                        </div>
                    </div>
            </div>
            <div class="item w-100 mb-2">
                <div class="col-12">
                   PYHON (DJANGO) - oyrenmiyecem :/
                </div>
                 <div class="col-12">
                        <div class="progress w-100">
                            <div class="progress-bar bg-dark" role="progressbar" style="width: 10%;"
                                aria-valuenow="10" aria-valuemin="0" aria-valuemax="100">10%</div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</template>