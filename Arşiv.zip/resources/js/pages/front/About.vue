<template>
    <div class="about-section section">
        burasi about
    </div>
</template>